/** PAR, Procesadores de Alto Rendimiento - GII (Ingenieria de Computadores)

    histo.c  --  versión serie

     - paralelización de bucles
     - tipos de variables
     - paralelismo de grano fino y de grano grueso
     - reparto de iteraciones (scheduling)
***************************************************************************/
#include <stdio.h>
#include <stdlib.h>

#define N  5000
#define MAX 10 

int  mat[N][N];

int main (){
  int  i, j, k, histo[MAX], hmin, imin;
  int suma_fil[N], suma_col[N];

  // valores iniciales, NO paralelizar
  for(i=0; i<N; i++)
  for(j=0; j<N; j++) {
    if (i%3) mat[i][j] = (i+j) % MAX;
    else     mat[i][j] = (i+i*j) % MAX;
  }

  for (i=0; i<MAX; i++) histo[i] = 0;

  for (i=0; i<N; i++){
	  suma_fil[i] = 0;
	  suma_col[i] = 0;
  }

  // ========================
  // === PARA PARALELIZAR ===
  // ========================
  for (i=0; i<N; i++)
    for (j=0; j<N; j++)
      histo[mat[i][j]]++; // histograma

  hmin = N*N + 1;
  for (i=0; i<MAX; i++){ // el valor minimo de la histograma y su posicion
	  if (hmin > histo[i]){
		  hmin = histo[i];
		  imin = i;
	  }
  }

  for (i=0; i<N; i++) // suma de las filas de la matriz
	  for (j=0; j<N; j++)
		  suma_fil[i] += mat[i][j];

  for (j=0; j<N; j++) // suma de las columnas de la matriz
	  for (i=0; i<N; i++)
		  suma_col[j] += mat[i][j];

  // === FIN DE LA REGION PARALELA ===

  printf ("\n Histograma de la matriz mat[%d][%d] (con %d valores diferentes)\n", N, N, MAX);
  printf (" ===========================================================\n");
  for (k=0; k<MAX; k++) printf ("%9d", k);
  printf ("\n");
  for (k=0; k<MAX; k++) printf ("%9d", histo[k]);
  printf ("\n");

  printf ("\n El minimo de la histograma: %d, posicion %d\n", hmin, imin);
  printf ("\n La suma de la fila 100: %d ", suma_fil[100]);
  printf ("\n La suma de la columna 200: %d \n\n", suma_col[200]);
}

