package packpub;

//import java.util.ArrayList;

public class OrderSet {
    // private ArrayList<Order> orders;

    // public OrderSet() {
    //     orders = new ArrayList<Order>();
    // }
    // public addOrder(Order order){
    //     orders.add(order);
    // }
    
}
