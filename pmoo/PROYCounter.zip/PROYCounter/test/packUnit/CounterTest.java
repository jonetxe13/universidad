package packUnit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
@DisplayName("Test para la clase Counter")
class CounterTest {
	Counter counter1;
	@BeforeEach
	void setUp() throws Exception {
		counter1 = new Counter();
	}

	@Test
	@DisplayName("Prueba inicializaci�n correcta")
	void testIncrement() {
        assertEquals(1, counter1.increment());
        assertEquals(2, counter1.increment());
	}

	@Test
	void testDecrement() {
		assertTrue(counter1.decrement() == -1, "Se esperaba -1 y no ha funcionado bien el decrement");
	}

}
