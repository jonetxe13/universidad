/* clock.c */

#include <stdlib.h>

main(int argc, char *argv[])	
{ 
   sleep(atoi(argv[1]));
}
